function tecla(){
	var evento = window.event;
	console.log(evento.KeyCode);
}