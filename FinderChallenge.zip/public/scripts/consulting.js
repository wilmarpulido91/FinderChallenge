function consulting(){
	// code here
	console.log('Clic en consultar.');

}