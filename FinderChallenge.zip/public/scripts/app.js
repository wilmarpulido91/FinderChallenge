/*
  main script for only runs every function
*/
searchForm();
complete();